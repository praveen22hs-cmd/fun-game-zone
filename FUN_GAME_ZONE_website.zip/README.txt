FUN GAME ZONE — Starter Website

Files:
- index.html: the complete responsive website. No frameworks or external dependencies required.

Included playable mini-games:
- Neon Tap Challenge
- Memory Match
- Guess the Number
- Reaction Test
- Rock Paper Scissors
- Quick Math

Preview locally:
Open index.html in a modern browser.

Free publishing with GitHub Pages:
1. Create/sign in to a GitHub account.
2. Create a new public repository named fun-game-zone.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select main and /(root), then Save.
7. Wait for deployment and open the URL shown in Settings > Pages.

Note: GitHub UI labels can change. The site is a static front-end; it does not include accounts, multiplayer servers, or payment processing.
